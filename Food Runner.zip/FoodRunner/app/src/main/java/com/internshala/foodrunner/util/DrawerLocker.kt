package com.internshala.foodrunner.util

interface DrawerLocker {
    fun setDrawerEnabled(enabled: Boolean)
}